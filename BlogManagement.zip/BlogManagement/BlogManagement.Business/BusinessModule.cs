﻿using Autofac;
using AutoMapper;
using BlogManagement.Business.Contracts;
using BlogManagement.Business.Dtos;
using BlogManagement.Data;
using BlogManagement.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlogManagement.Business
{
    public class BusinessModule : Module
    {
        private string connectionString;
        public BusinessModule(string connString)
        {
            connectionString = connString;
            RegisterMapper();
        }

        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<UserBusinessService>().As<IUserBusinessService>().InstancePerRequest();
            builder.RegisterType<BlogBusinessService>().As<IBlogBusinessService>().InstancePerRequest();
            builder.RegisterType<ImageBusinessService>().As<IImageBusinessService>().InstancePerRequest();
            builder.RegisterType<CommentBusinessService>().As<ICommentBusinessService>().InstancePerRequest();
            builder.RegisterType<CategoryBusinessService>().As<ICategoryBusinessService>().InstancePerRequest();

            builder.RegisterModule(new DataModule(connectionString));
            base.Load(builder);
        }

        private void RegisterMapper()
        {
            Mapper.CreateMap<BaseEntity, BaseDto>();
            Mapper.CreateMap<BaseDto, BaseEntity>();

            Mapper.CreateMap<User, UserDto>();
            Mapper.CreateMap<UserDto, User>();

            Mapper.CreateMap<Category, CategoryDto>();
            Mapper.CreateMap<CategoryDto, Category>();

            Mapper.CreateMap<Blog, BlogDto>();
            Mapper.CreateMap<BlogDto, Blog>();

            Mapper.CreateMap<Image, ImageDto>();
            Mapper.CreateMap<ImageDto, Image>();

            Mapper.CreateMap<Comment, CommentDto>();
            Mapper.CreateMap<CommentDto, Comment>();
        }
    }
}
