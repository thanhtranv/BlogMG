﻿using AutoMapper;
using BlogManagement.Business.Contracts;
using BlogManagement.Business.Dtos;
using BlogManagement.Data.Contracts;
using BlogManagement.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace BlogManagement.Business
{
    public class UserBusinessService : BaseBusinessService, IUserBusinessService
    {
        private IRepository<User> userRepository;

        public UserBusinessService(IRepository<User> repo)
        {
            userRepository = repo;
        }

        public void DeleteUser(UserDto userDto)
        {
            var user = Mapper.Map<User>(userDto);

            userRepository.Delete(user);
            userRepository.SaveChanges();
        }

        public IList<UserDto> GetAllUsers()
        {
            var user = userRepository.GetAll();
            var userDtos = (IList<UserDto>)Mapper.Map(user, user.GetType(), typeof(IList<UserDto>));
            return userDtos;
        }

        public UserDto GetUserById(Guid Id)
        {
            var user = userRepository.GetById(Id);
            return Mapper.Map<User, UserDto>(user);
        }

        public UserDto InsertUser(UserDto userDto)
        {
            var user = Mapper.Map<User>(userDto);
            user = userRepository.Insert(user);
            userRepository.SaveChanges();

            return Mapper.Map<User, UserDto>(user);
        }

        public IList<UserDto> SearchUserByName(string userName, int pageIndex, int pageSize, out int total)
        {
            var user = userRepository.Search(p => p.Username.Contains(userName), o => o.Username, pageIndex, pageSize, out total);
            var userDtos = (IList<UserDto>)Mapper.Map(user, user.GetType(), typeof(IList<UserDto>));

            return userDtos;
        }

        public void UpdateUser(UserDto userDto)
        {
            var user = Mapper.Map<User>(userDto);

            userRepository.Update(user);
            userRepository.SaveChanges();
        }

        public UserDto GetUserByName(string userName)
        {
            var users = userRepository.GetAll();
            UserDto userDto = new UserDto();
            foreach (var item in users)
            {
                if (item.Username.ToUpper().Equals(userName.ToUpper()))
                {
                    userDto.ID = item.ID;
                    userDto.Username = item.Username;
                    userDto.Password = item.Password;
                    userDto.Phone = item.Phone;
                    userDto.Address = item.Address;
                    userDto.Role = item.Role;
                    userDto.Image = item.Image;
                    userDto.Gender = item.Gender;
                }
            }
            return userDto;
            
        }

        public int checkLogin(string userName, string password)
        {
          

            var userLogin = from user in userRepository.GetAll()
                            where (user.Username == userName) && (user.Password == EncodeSHA1(password))
                            select user;

            if (userLogin != null)
            {
                return 1;
            }
            return 0;

            //foreach (var item in user)
            //{
            //    if (userName == item.Username && EncodeSHA1(password) == item.Password)
            //    {
            //        return 1;
            //    }
            //}
            //return 0;
        }

        public string EncodeSHA1(string pass)
        {
            SHA1CryptoServiceProvider sha1 = new SHA1CryptoServiceProvider();
            byte[] bs = System.Text.Encoding.UTF8.GetBytes(pass);
            bs = sha1.ComputeHash(bs);
            System.Text.StringBuilder s = new System.Text.StringBuilder();
            foreach (byte b in bs)
            {
                s.Append(b.ToString("x1"));
            }
            pass = s.ToString();
            return pass;
        }

        public string HashSHA1Decryption(string value)
        {
            var shaSHA1 = SHA1.Create();
            var inputEncodingBytes = Encoding.ASCII.GetBytes(value);
            var hashString = shaSHA1.ComputeHash(inputEncodingBytes);

            var stringBuilder = new StringBuilder();
            for (var x = 0; x < hashString.Length; x++)
            {
                stringBuilder.Append(hashString[x].ToString("X2"));
            }
            return stringBuilder.ToString();
        }
    }

}
