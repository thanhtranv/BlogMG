﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlogManagement.Data.Entities
{
    public class Comment : BaseEntity
    {
        public string Content { get; set; }
        public DateTime CommentDate { get; set; }
        public Guid IDUser { get; set; }
        public Guid IDBlog { get; set; }

        public virtual User User { get; set; }
        public virtual Blog Blog { get; set; }
    }
}
