﻿using Autofac;
using BlogManagement.Data.Contracts;
using BlogManagement.Data.Entities;
using BlogManagement.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlogManagement.Data
{
    public class DataModule : Module
    {
        private string connectionString;

        public DataModule(string connString)
        {
            connectionString = connString;
        }

        protected override void Load(ContainerBuilder builder)
        {
            builder.Register(c => new BlogDbContext(this.connectionString)).As<IDbContext>().InstancePerRequest();
            RegisterRepository<User>(builder);
            RegisterRepository<Category>(builder);
            RegisterRepository<Blog>(builder);
            RegisterRepository<Comment>(builder);
            RegisterRepository<Image>(builder);

            base.Load(builder);
        }

        private void RegisterRepository<TEntity>(ContainerBuilder builder) where TEntity : BaseEntity
        {
            builder.RegisterType<BaseRepository<TEntity>>().As<IRepository<TEntity>>().InstancePerRequest();
        }
    }
}
