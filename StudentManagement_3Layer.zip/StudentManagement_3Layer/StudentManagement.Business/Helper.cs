﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement.Business
{
    public class Helper
    {
        public static string EncodeSHA1(string pass)
        {
            SHA1CryptoServiceProvider sha1 = new SHA1CryptoServiceProvider();
            byte[] bs = System.Text.Encoding.UTF8.GetBytes(pass);
            bs = sha1.ComputeHash(bs);
            System.Text.StringBuilder s = new System.Text.StringBuilder();
            foreach (byte b in bs)
            {
                s.Append(b.ToString("x1"));
            }
            pass = s.ToString();
            return pass;
        }
        //public static string Encode(string value)
        //{
        //    var hash = System.Security.Cryptography.SHA1.Create();
        //    var encoder = new System.Text.ASCIIEncoding();
        //    var combined = encoder.GetBytes(value ?? "");
        //    return BitConverter.ToString(hash.ComputeHash(combined)).ToLower().Replace("-", "");
        //}

        public static string HashSHA1Decryption(string value)
        {
            var shaSHA1 = SHA1.Create();
            var inputEncodingBytes = Encoding.ASCII.GetBytes(value);
            var hashString = shaSHA1.ComputeHash(inputEncodingBytes);

            var stringBuilder = new StringBuilder();
            for (var x = 0; x < hashString.Length; x++)
            {
                stringBuilder.Append(hashString[x].ToString("X2"));
            }
            return stringBuilder.ToString();
        }
    }
}
