namespace StudentManagement.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.User", name: "Role_ID", newName: "RoleEntity_ID");
            RenameIndex(table: "dbo.User", name: "IX_Role_ID", newName: "IX_RoleEntity_ID");
            AddColumn("dbo.User", "Role", c => c.String());
            DropColumn("dbo.User", "IDRole");
        }
        
        public override void Down()
        {
            AddColumn("dbo.User", "IDRole", c => c.Guid(nullable: false));
            DropColumn("dbo.User", "Role");
            RenameIndex(table: "dbo.User", name: "IX_RoleEntity_ID", newName: "IX_Role_ID");
            RenameColumn(table: "dbo.User", name: "RoleEntity_ID", newName: "Role_ID");
        }
    }
}
