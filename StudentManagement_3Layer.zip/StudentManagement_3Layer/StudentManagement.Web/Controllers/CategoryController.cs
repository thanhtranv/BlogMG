﻿using StudentManagement.Business.Contracts;
using StudentManagement.Business.Dtos;
using StudentManagement.Web.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace StudentManagement.Web.Controllers
{
    public class CategoryController : Controller
    {
        private ICategoryBusinessService categoryService;

        public CategoryController(ICategoryBusinessService service)
        {
            categoryService = service;
        }

        // GET: Category
        public ActionResult Index()
        {
            var categories = categoryService.GetAllCategories();
            return View();
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(CreateCategoryViewModel categoryModel)
        {
            try
            {
                CategoryDto categoryDto = new CategoryDto();
                categoryDto.Name = categoryModel.Name;

                if (ModelState.IsValid)
                {
                    var category = categoryService.GetCategoryByName(categoryModel.Name);
                    if (category == null)
                    {
                        categoryService.InsertCategory(categoryDto);
                        return Content("<script>alert('Successfully inserted')</script>");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Category existed");
                        
                    }
                }
            }
            catch (DataException)
            {

                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View();
        }
    }
}